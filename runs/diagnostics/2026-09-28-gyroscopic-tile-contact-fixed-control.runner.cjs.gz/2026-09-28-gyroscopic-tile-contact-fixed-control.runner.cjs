const fs = require('node:fs/promises');
const { spawn } = require('node:child_process');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const assert = require('node:assert/strict');
const { validationCodeHash, artifactHashes } = require(process.cwd() + '/lib/replication/provenance.ts');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');

(async () => {
  const prefix = 'runs/diagnostics/2026-09-28-gyroscopic-tile-contact-fixed-control';
  const native = '/tmp/magnatiles-gyroscopic-probe-f64-principal-frame';
  const pkg = native + '/source/rapier-compat/builds/3d/pkg';
  const matrix = '/tmp/magnatiles-gyroscopic-tile-contact-fixed-control.json';
  const report = '/tmp/magnatiles-gyroscopic-tile-contact-fixed-control.vitest.json';
  const log = '/tmp/magnatiles-gyroscopic-tile-contact-fixed-control.log';
  const inputs = ['scripts/reference/gyroscopic-tile-contact-qualified.config.ts', 'scripts/reference/gyroscopic-frozen-negative-control.ts', 'scripts/reference/gyroscopic-negative-seed.json', 'runs/2026-09-28-gyroscopic-fixed-control-plan.md', 'runs/diagnostics/2026-09-28-gyroscopic-negative-seed.production.log.txt', 'runs/diagnostics/2026-09-28-gyroscopic-negative-seed.manifest.json', 'scripts/reference/gyroscopic-tile-probe.config.ts', 'scripts/reference/probe-gyroscopic-tile-contact.ts',
    'scripts/reference/gyroscopic-probe-context.ts', 'scripts/reference/gyroscopic-f64-profile.json', 'scripts/reference/probe-gyroscopic-semantics.config.ts',
    'runs/2026-09-28-gyroscopic-tile-contact-plan.md', 'tests/fixtures/contact-frames.ts', 'tests/fixtures/unpatched-contact.ts',
    'tests/triangle-contact.test.ts', 'tests/rectangular-contact.test.ts', 'tests/polyhedral-contact.test.ts',
    'lib/engine/build.ts', 'lib/engine/physics-model.ts', 'lib/engine/rapier-world.ts', 'lib/engine/backend-identity.ts', 'lib/engine/constants.ts',
    'lib/engine/physics-backend.ts', 'lib/replication/provenance.ts', 'vitest.config.ts'];
  const nativeInputs = [native + '/build-proof.json', native + '/principal-frame.patch', native + '/gyroscopic-binding.patch', pkg + '/rapier.cjs', pkg + '/rapier_wasm3d_bg.wasm', require('node:module').createRequire(process.cwd() + '/package.json').resolve('@dimforge/rapier3d-compat')];
  const context = async () => ({ validationCodeHash: await validationCodeHash(), inputHashes: await artifactHashes(inputs), nativeHashes: await artifactHashes(nativeInputs), runnerSha256: hash(await fs.readFile(__filename)) });
  const initial = await context();
  const frozenSeed = JSON.parse(await fs.readFile('scripts/reference/gyroscopic-negative-seed.json','utf8'));
  assert.equal(frozenSeed.sourceLogSha256, hash(await fs.readFile('runs/diagnostics/2026-09-28-gyroscopic-negative-seed.production.log.txt')));
  assert.equal(initial.validationCodeHash, 'b354b6edcbcddb7248137e9888e97badfcb7eb2156f742760783587be5dbcf1a');
  for (const path of [matrix, report, log, prefix + '.manifest.json']) {
    try { await fs.access(path); throw Error('Existing attempt: ' + path); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
  const evidence = { scope: 'Full-coordinate f64 corrected-gyro tile contacts with existing production hinges. Historical unpatched negative control uses frozen original production inputs with exact replay assertions. Not compliant seams, folding or source acceptance.',
    startedAt: new Date().toISOString(), completed: false, executionCompleted: false, context: initial, archives: [] };
  const save = async () => { const path = prefix + '.manifest.json'; await fs.writeFile(path + '.tmp', JSON.stringify(evidence, null, 2) + '\n'); await fs.rename(path + '.tmp', path); };
  const archive = async (source, suffix) => {
    const raw = await fs.readFile(source), bytes = suffix.endsWith('.gz') ? zlib.gzipSync(raw) : raw, path = prefix + '.' + suffix;
    await fs.writeFile(path, bytes, { flag: 'wx' }); evidence.archives.push({ source, path, rawSha256: hash(raw), sha256: hash(bytes) });
  };
  for (const [i, source] of inputs.entries()) await archive(source, 'input-' + i + '.gz');
  for (const [i, source] of nativeInputs.slice(0, 3).entries()) await archive(source, 'native-input-' + i + '.gz');
  await archive(__filename, 'runner.cjs.gz'); await save();
  const command = ['npx', 'vitest', 'run', '--config', 'scripts/reference/gyroscopic-tile-contact-qualified.config.ts', '--reporter=default', '--reporter=json', '--outputFile=' + report];
  const fd = await fs.open(log, 'wx'), start = performance.now();
  const child = spawn(command[0], command.slice(1), { cwd: process.cwd(),
    env: { ...process.env, MAGNATILES_TILE_CONTACT_REPORT: matrix, MAGNATILES_GYRO_PRECISION: 'f64', MAGNATILES_GYRO_FRAME_FIX: '1', MAGNATILES_GYRO_MODE: 'on' }, stdio: ['ignore', fd.fd, fd.fd] });
  console.log(JSON.stringify({ pid: child.pid, log, matrix }));
  const result = await new Promise((resolve, reject) => { child.once('error', reject); child.once('close', (code, signal) => resolve({ code, signal })); });
  await fd.close();
  evidence.run = { command, ...result, durationSeconds: (performance.now() - start) / 1000 };
  for (const [path, suffix] of [[log, 'log.txt'], [report, 'vitest.json.gz'], [matrix, 'matrix.json.gz']]) {
    try { await archive(path, suffix); } catch (error) { if (error.code !== 'ENOENT') throw error; (evidence.missing ||= []).push(path); }
  }
  if (!evidence.missing) {
    const m = JSON.parse(await fs.readFile(matrix, 'utf8')), r = JSON.parse(await fs.readFile(report, 'utf8'));
    evidence.results = { expectedRows: m.expectedRows, rows: m.rows.length, passedRows: m.rows.filter(row => row.trial?.passed && !row.error).length,
      matrixCompleted: m.completed, totalTests: r.numTotalTests, passedTests: r.numPassedTests, failedTests: r.numFailedTests, pendingTests: r.numPendingTests };
    evidence.executionCompleted = m.expectedRows === 198 && m.rows.length === 198 && r.numPassedTests + r.numFailedTests === 15;
    evidence.completed = evidence.executionCompleted && m.completed && result.code === 0 && r.numPassedTests === 15 && r.numFailedTests === 0;
  }
  evidence.finalContext = await context();
  evidence.contextUnchanged = JSON.stringify(evidence.context) === JSON.stringify(evidence.finalContext);
  evidence.completed &&= evidence.contextUnchanged;
  evidence.finishedAt = new Date().toISOString(); await save();
  console.log(JSON.stringify({ completed: evidence.completed, executionCompleted: evidence.executionCompleted, results: evidence.results, run: evidence.run, missing: evidence.missing }));
  if (!evidence.completed) process.exitCode = 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
