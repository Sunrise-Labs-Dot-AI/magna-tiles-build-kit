const fs=require('node:fs/promises'),{spawn}=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const {validationCodeHash,artifactHashes}=require(process.cwd()+'/lib/replication/provenance.ts');
const expected='b354b6edcbcddb7248137e9888e97badfcb7eb2156f742760783587be5dbcf1a';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const prerequisite=JSON.parse(await fs.readFile('runs/diagnostics/2026-09-28-source-sets-source-retry.manifest.json','utf8'));
 if(!prerequisite.completed)throw Error('Finish source reports before another native run');
 const prefix='runs/diagnostics/2026-09-28-spring-semantics-v2',report='/tmp/magnatiles-spring-semantics-v2.json',log='/tmp/magnatiles-spring-semantics-v2.log';
 for(const file of [prefix+'.manifest.json',report]){try{await fs.access(file);throw Error('Preserve existing attempt: '+file);}catch(e){if(e.code!=='ENOENT')throw e;}}
 const inputs=['scripts/reference/probe-spring-semantics.ts','scripts/reference/probe-spring-semantics.config.ts','runs/2026-09-28-compliant-seam-plan.md'];
 const context={validationCodeHash:await validationCodeHash(),inputHashes:await artifactHashes(inputs)};
 if(context.validationCodeHash!==expected)throw Error('Wrong runtime');
 const command=['npx','vitest','run','--config','scripts/reference/probe-spring-semantics.config.ts'];
 const evidence={scope:'Isolated native spring semantics. No tile-seam, source, assembly or release acceptance. Independent code/results review pending.',command,context,startedAt:new Date().toISOString(),runnerSha256:sha(await fs.readFile(__filename)),completed:false};
 const save=()=>fs.writeFile(prefix+'.manifest.json',JSON.stringify(evidence,null,2)+'\n');await save();
 const fd=await fs.open(log,'w'),start=performance.now(),child=spawn(command[0],command.slice(1),{cwd:process.cwd(),env:{...process.env,MAGNATILES_SPRING_REPORT:report},stdio:['ignore',fd.fd,fd.fd]});
 console.log(JSON.stringify({pid:child.pid,log,report}));
 const result=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});await fd.close();
 Object.assign(evidence,{finishedAt:new Date().toISOString(),durationSeconds:(performance.now()-start)/1000,exitCode:result.code,signal:result.signal,finalContext:{validationCodeHash:await validationCodeHash(),inputHashes:await artifactHashes(inputs)}});
 evidence.contextUnchanged=JSON.stringify(context)===JSON.stringify(evidence.finalContext);evidence.archives=[];
 for(const [source,name] of [[log,'log.txt'],[report,'json.gz'],[inputs[0],'script.ts.gz'],[inputs[1],'config.ts.gz'],[inputs[2],'plan.md.gz'],[__filename,'runner.cjs.gz']]){
  let raw;try{raw=await fs.readFile(source);}catch(e){if(e.code==='ENOENT'){evidence.archives.push({source,missing:true});continue;}throw e;}
  const bytes=name.endsWith('.gz')?zlib.gzipSync(raw,{mtime:0}):raw,path=prefix+'.'+name;
  await fs.writeFile(path,bytes);evidence.archives.push({source,path,rawSha256:sha(raw),sha256:sha(bytes)});
 }
 let reportCompleted=false;try{const r=JSON.parse(await fs.readFile(report,'utf8'));reportCompleted=r.completed===true&&r.error===null&&r.checks.length>0&&r.checks.every(c=>c.pass===true)&&r.forces.length===11&&r.free.length===13;}catch{} evidence.reportCompleted=reportCompleted; evidence.completed=result.code===0&&evidence.contextUnchanged&&reportCompleted;await save();console.log(JSON.stringify(evidence));
 if(!evidence.completed)process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
