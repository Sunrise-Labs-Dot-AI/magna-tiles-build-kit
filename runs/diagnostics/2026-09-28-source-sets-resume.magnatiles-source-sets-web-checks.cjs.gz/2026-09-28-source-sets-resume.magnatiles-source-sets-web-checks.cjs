const fs=require('node:fs/promises'),{spawn}=require('node:child_process'),crypto=require('node:crypto');
const {validationCodeHash}=require(process.cwd()+'/lib/replication/provenance.ts');
const expected='b354b6edcbcddb7248137e9888e97badfcb7eb2156f742760783587be5dbcf1a';
const prefix='runs/diagnostics/2026-09-28-source-sets-web-checks';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const priorBytes=await fs.readFile('runs/diagnostics/2026-09-28-source-sets-qualification.manifest.json');
 const prior=JSON.parse(priorBytes),retry=JSON.parse(await fs.readFile('runs/diagnostics/2026-09-28-source-sets-source-retry.manifest.json','utf8'));
 if(!retry.completed||retry.context.validationCodeHash!==expected||retry.prerequisite.sha256!==sha(priorBytes)||
   retry.stages.length!==2||JSON.stringify(retry.stages.map(s=>s.name))!==JSON.stringify(['source-reports','artifact-gate'])||
   retry.stages.some(s=>s.exitCode!==0||!s.contextUnchanged||!s.outputsCurrent)||
   ['focused96','configured72','generic-assembly'].some(name=>!prior.stages.some(s=>s.name===name&&s.exitCode===0&&s.contextUnchanged)))
   throw Error('Completed prerequisites and actual successful source/artifact retry are required');
 for(const stage of [...prior.stages.filter(s=>['focused96','configured72','generic-assembly'].includes(s.name)),...retry.stages]){
   if(sha(await fs.readFile(stage.log))!==stage.logSha256)throw Error('Qualification log changed');
   for(const output of stage.outputs)if(sha(await fs.readFile(output.file))!==output.sha256)throw Error('Qualification output changed: '+output.file);
 }
 if(await validationCodeHash()!==expected)throw Error('Wrong starting validator');
 const evidence={scope:'Source-set integration lint, type and production build checks after completed frozen current-context regeneration.',startedAt:new Date().toISOString(),validationCodeHash:expected,runnerSha256:sha(await fs.readFile(__filename)),completed:false,stages:[]};
 const save=()=>fs.writeFile(prefix+'.manifest.json',JSON.stringify(evidence,null,2)+'\n');await save();
 for(const [name,cmd,args] of [['lint','npm',['run','lint']],['types','npx',['tsc','--noEmit']],['build','npm',['run','build']]]){
  const log=`/tmp/magnatiles-source-sets-${name}.log`,fd=await fs.open(log,'w'),startedAt=new Date().toISOString(),start=performance.now();
  const child=spawn(cmd,args,{cwd:process.cwd(),stdio:['ignore',fd.fd,fd.fd]});console.log(JSON.stringify({state:'started',name,pid:child.pid,log}));
  const exit=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});await fd.close();
  const bytes=await fs.readFile(log),archive=prefix+'.'+name+'.log.txt';await fs.writeFile(archive,bytes);
  const contextUnchanged=await validationCodeHash()===expected,row={name,command:[cmd,...args],startedAt,finishedAt:new Date().toISOString(),durationSeconds:(performance.now()-start)/1000,exitCode:exit.code,signal:exit.signal,contextUnchanged,archive,logSha256:sha(bytes)};
  evidence.stages.push(row);await save();console.log(JSON.stringify(row));if(exit.code!==0||!contextUnchanged){process.exitCode=1;return;}
 }
 evidence.completed=true;evidence.finishedAt=new Date().toISOString();await save();
})().catch(error=>{console.error(error);process.exitCode=1;});
