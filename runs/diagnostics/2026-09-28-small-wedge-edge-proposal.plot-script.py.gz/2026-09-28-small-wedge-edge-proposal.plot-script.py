from pathlib import Path
import hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
root=Path('/Users/jamesheath/Documents/Claude/Projects/Worktrees/magnatiles-footage-replicas')
source=root/'public/reference-frames/replication/henry/small-fit-33.png'
expected='9595d6e202d8b246aaaaae839e028a31cfd212c4775dd2cb44ff9867c8d34fff'
assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
raw=[
 ('upper-back',[[1024,368],[977,477]]),
 ('upper-far',[[1063,363],[1235,466]]),
 ('upper-front',[[1269,520],[1240,625]]),
 ('upper-near',[[997,529],[1200,646]]),
 ('lower-back',[[1268,548],[1250,629]]),
 ('lower-far',[[1303,529],[1477,635]]),
 ('lower-front',[[1511,686],[1499,791]]),
 ('lower-near',[[1272,698],[1452,809]]),
]
rows=[{'id':name,'sourcePanelRole':'upper-deck' if name.startswith('upper') else 'lower-deck','segmentPixels':points,'draftBandPx':6,'feature':'Proposed visible exterior orange-plastic boundary; distinguish from internal frame decoration and yellow plastic seen through the face.','status':'unreviewed','occlusion':'Endpoints avoid rounded corners; physical boundary and visibility require independent review.'} for name,points in raw]
d={'scope':'Unreviewed fitting-only image measurement proposal. No catalog, source geometry, observation lock, source acceptance or runtime change.','sourceSha256':'2d2aca38030161b613d445154154e59a040514543079de9936869ba25d85bfe0','frameId':'small-fit-33','frameSha256':expected,'seconds':33,'width':1920,'height':1080,'partition':'fit','catalogSceneStageId':'small-launch','proposedMeasuredComponentStageId':'small-wedge','bindingStatus':'off-path proposal; production frame/stage binding remains unchanged','excludedComponent':'The separately held launch module.','uncertaintyMeaning':'Manual draft +/-6px boundary-selection band, not a statistical confidence interval. Reject or revise through image review before fitting.','segments':rows}
output=root/'runs/diagnostics/2026-09-28-small-wedge-edge-proposal.json';output.write_text(json.dumps(d,indent=2)+'\n')
fig,ax=plt.subplots(figsize=(11,8.5),dpi=130)
ax.imshow(Image.open(source));colors={'upper':'#0865ed','lower':'#b510b0'}
for i,row in enumerate(rows,1):
 p=np.array(row['segmentPixels'],dtype=float);v=p[1]-p[0];n=np.array([-v[1],v[0]])/np.linalg.norm(v)*row['draftBandPx'];c=colors[row['id'].split('-')[0]]
 polygon=np.array([p[0]+n,p[1]+n,p[1]-n,p[0]-n]);ax.fill(polygon[:,0],polygon[:,1],color=c,alpha=.25)
 ax.plot(p[:,0],p[:,1],'-o',color=c,linewidth=1.7,markersize=3)
 center=p.mean(axis=0);ax.annotate(str(i),center,xytext=(9,0),textcoords='offset points',color=c,weight='bold',bbox={'facecolor':'white','edgecolor':c,'alpha':.9,'boxstyle':'round,pad=.18'})
ax.set_xlim(835,1565);ax.set_ylim(880,310);ax.set_aspect('equal');ax.set_xlabel('Source pixel x');ax.set_ylabel('Source pixel y')
ax.set_title('Small wedge: proposed straight edge measurements\nFitting frame 33s · unreviewed bands · separately held launch excluded',fontsize=13)
fig.text(.5,.02,'1 upper back   2 upper far   3 upper front   4 upper near\n5 lower back   6 lower far   7 lower front   8 lower near',ha='center',fontsize=10)
fig.tight_layout(rect=(0,.065,1,1))
plot=root/'public/reference-frames/replication/henry/small-wedge-edge-proposal.png';fig.savefig(plot);plt.close(fig)
print(json.dumps({'annotation':str(output),'annotationSha256':hashlib.sha256(output.read_bytes()).hexdigest(),'localOnlyPlot':str(plot),'plotSha256':hashlib.sha256(plot.read_bytes()).hexdigest()}))
