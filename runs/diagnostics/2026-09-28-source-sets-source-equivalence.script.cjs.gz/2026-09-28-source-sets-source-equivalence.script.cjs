const fs=require('node:fs'), z=require('node:zlib'), crypto=require('node:crypto'), assert=require('node:assert/strict');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const retry=JSON.parse(fs.readFileSync('runs/diagnostics/2026-09-28-source-sets-source-retry.manifest.json'));
assert(retry.completed,'Require completed source retry, not intermediate report bytes');
const prior=JSON.parse(fs.readFileSync('runs/diagnostics/2026-09-27-final-qualification.manifest.json'));
const output=[];
for(const id of ['jet','small-ramp','medium-ramp','large-ramp']){
  const file=`public/reference-replicas/${id}.json`;
  const beforeRow=prior.stages.find(s=>s.name==='source-reports').outputs.find(o=>o.file===file);
  const packed=fs.readFileSync(beforeRow.archive),beforeBytes=z.gunzipSync(packed),afterBytes=fs.readFileSync(file);
  assert.equal(sha(beforeBytes),beforeRow.sha256);assert.equal(sha(packed),beforeRow.gzipSha256);
  assert.equal(sha(afterBytes),retry.stages[0].outputs.find(o=>o.file===file).sha256);
  const before=JSON.parse(beforeBytes),after=JSON.parse(afterBytes);
  const sections=[];
  for(const [root,keys] of [['report',['projections','releases','stages','constructionPaths','assemblySimulation','holdoutCoverage','carTrials']],['replica',['build','inventory','construction','route']]]){
    for(const key of keys){assert.deepEqual(after[root][key],before[root][key],`${id}.${root}.${key} changed`);
      sections.push({path:`${root}.${key}`,identical:true,sha256:sha(JSON.stringify(after[root][key])??'undefined')});}
  }
  const differences=[];
  const diff=(a,b,path='')=>{
    if(JSON.stringify(a)===JSON.stringify(b))return;
    if(a&&b&&typeof a==='object'&&typeof b==='object'&&Array.isArray(a)===Array.isArray(b)){
      for(const key of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[key],b[key],path?`${path}.${key}`:key);
    }else differences.push({path,before:a,after:b});
  };
  diff(before,after);
  output.push({id,beforeSha256:sha(beforeBytes),afterSha256:sha(afterBytes),identicalPhysicalAndProjectionSections:sections,differences});
}
const result={scope:'Exact JSON payload comparison to qualified245e440 baseline. Source accounting, source checkpoint and instruction/provenance differences are listed separately; identical physical trajectories do not establish complete replica acceptance.',baselineContext:prior.context.validationCodeHash,currentContext:retry.context.validationCodeHash,rows:output};
fs.writeFileSync('runs/diagnostics/2026-09-28-source-sets-source-equivalence.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(output.map(x=>({id:x.id,identicalSections:x.identicalPhysicalAndProjectionSections.length,differencePaths:x.differences.map(d=>d.path)})),null,2));
