// Sequential verification, with immutable input checks around every producer.
const fs=require('node:fs/promises'),{spawn}=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const {validationCodeHash,artifactHashes}=require(process.cwd()+'/lib/replication/provenance.ts');
const expected='b354b6edcbcddb7248137e9888e97badfcb7eb2156f742760783587be5dbcf1a';
const baseline='3a2ed4ddf041cbf7615825b5e75dd6b3132f520d65c19ff662896a1285b5381d';
const prefix='runs/diagnostics/2026-09-28-source-sets-source-retry';
const priorPath='runs/diagnostics/2026-09-28-source-sets-qualification.manifest.json';
const sourceInputs=['sources','observations','observation-lock','evidence-ledger','candidate-freezes','source-pieces','frame-manifest'].map(n=>`verification/replication/${n}.json`);
sourceInputs.push('tests/source-pieces.test.ts','tests/evidence-gates.test.ts');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const stages=[
 {name:'source-reports',command:'node',args:['--import','tsx','scripts/reference/verify.ts','--report-only','--max-ms=900000'],outputs:['public/reference-replicas/jet.json','public/reference-replicas/small-ramp.json','public/reference-replicas/medium-ramp.json','public/reference-replicas/large-ramp.json','verification/replication/results.json','verification/replication/artifact-manifest.json']},
 {name:'artifact-gate',command:'npm',args:['run','reference:check-artifacts'],outputs:[]},
];
(async()=>{
 const full=JSON.parse(await fs.readFile('runs/diagnostics/2026-09-27-final-context-full-tests.manifest.json','utf8'));
 if(full.exitCode!==0||!full.contextUnchanged||full.context.validationCodeHash!==baseline)throw Error('Require actual passing full regression on the frozen context');
 const changed=require('node:child_process').execFileSync('git',['diff','--name-only','245e440a2a8edb3eb16c05bfc1da14173aa4b1a3','HEAD'],{encoding:'utf8'}).trim().split('\n').sort();
 const allowed=['lib/replication/models.ts','lib/replication/source-pieces.ts','tests/source-pieces.test.ts','verification/replication/observation-history/2026-09-28-pre-observed-sets-observation-lock.json','verification/replication/observation-history/2026-09-28-pre-observed-sets-source-pieces.json','verification/replication/observation-lock.json','verification/replication/source-pieces.json'].sort();
 if(JSON.stringify(changed)!==JSON.stringify(allowed))throw Error('Unexpected committed integration scope');
 const context={validationCodeHash:await validationCodeHash(),sourceInputs:await artifactHashes(sourceInputs)};
 if(context.validationCodeHash!==expected)throw Error('Wrong starting runtime');
 const priorBytes=await fs.readFile(priorPath),prior=JSON.parse(priorBytes),priorSha256=sha(priorBytes);
 if(JSON.stringify(prior.context)!==JSON.stringify(context))throw Error('Completed prerequisite context differs');
 const inheritedStages=['focused96','configured72','generic-assembly'].map(name=>{
   const matches=prior.stages.filter(s=>s.name===name);
   if(matches.length!==1||matches[0].exitCode!==0||!matches[0].contextUnchanged)throw Error('Missing successful prerequisite: '+name);
   return matches[0];
 });
 const verifyPrior=async()=>{
   if(sha(await fs.readFile(priorPath))!==priorSha256)throw Error('Prerequisite manifest changed');
   for(const stage of inheritedStages){
     if(sha(await fs.readFile(stage.log))!==stage.logSha256)throw Error('Prerequisite log changed');
     for(const output of stage.outputs){
       const packed=await fs.readFile(output.archive);
       if(sha(packed)!==output.gzipSha256||sha(zlib.gunzipSync(packed))!==output.sha256||sha(await fs.readFile(output.file))!==output.sha256)
         throw Error('Prerequisite output changed: '+output.file);
     }
   }
 };
 await verifyPrior();
 if(process.argv.includes('--preflight-only')){
   console.log(JSON.stringify({preflight:'pass',validationCodeHash:expected,priorSha256,preservedStages:inheritedStages.map(s=>s.name),willRun:stages.map(s=>s.name),simulationsStarted:false}));return;
 }
 try{await fs.access(prefix+'.manifest.json');throw Error('Retry evidence already exists; preserve it rather than overwriting.');}
 catch(error){if(error.code!=='ENOENT')throw error;}

 const check=async()=>{const now={validationCodeHash:await validationCodeHash(),sourceInputs:await artifactHashes(sourceInputs)};if(JSON.stringify(now)!==JSON.stringify(context))throw Error('Frozen qualification inputs changed');await verifyPrior();};
 const evidence={scope:'Targeted source-report retry after documented host sleep. The completed focused96/contact72/generic fixture runs remain bound to their original evidence; they are not rerun or restamped. Report-only completion is not replica acceptance.',prerequisite:{path:priorPath,sha256:priorSha256,stages:inheritedStages.map(s=>s.name)},baseline:{commit:'245e440a2a8edb3eb16c05bfc1da14173aa4b1a3',validationCodeHash:baseline,fullTests:'runs/diagnostics/2026-09-27-final-context-full-tests.manifest.json',qualification:'runs/diagnostics/2026-09-27-final-qualification.manifest.json',changedFiles:changed},context,startedAt:new Date().toISOString(),runnerSha256:sha(await fs.readFile(__filename)),completed:false,stages:[]};
 const save=async()=>{await fs.writeFile(prefix+'.manifest.json.tmp',JSON.stringify(evidence,null,2)+'\n');await fs.rename(prefix+'.manifest.json.tmp',prefix+'.manifest.json');};
 await save();
 for(const spec of stages){
  await check();const log=`/tmp/magnatiles-source-sets-retry-${spec.name}.log`,fd=await fs.open(log,'w'),start=performance.now(),startedAt=new Date().toISOString();
  const child=spawn(spec.command,spec.args,{cwd:process.cwd(),stdio:['ignore',fd.fd,fd.fd]});
  await fs.writeFile('/tmp/magnatiles-source-sets-source-retry-active.json',JSON.stringify({state:'running',stage:spec.name,pid:child.pid,log,startedAt,validationCodeHash:expected},null,2)+'\n');
  console.log(JSON.stringify({state:'started',stage:spec.name,pid:child.pid,log}));
  const result=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});await fd.close();
  const logBytes=await fs.readFile(log),archiveLog=`${prefix}.${spec.name}.log.txt`;await fs.writeFile(archiveLog,logBytes);
  const outputs=[];for(const file of spec.outputs){const bytes=await fs.readFile(file),packed=zlib.gzipSync(bytes,{mtime:0});const archive=`${prefix}.${spec.name}.${file.replaceAll('/','_')}.gz`;await fs.writeFile(archive,packed);outputs.push({file,sha256:sha(bytes),archive,gzipSha256:sha(packed)});}
  let contextUnchanged=true;try{await check();}catch{contextUnchanged=false;}
  let reportFreshness=null;
  if(spec.name==='source-reports'){
    reportFreshness=await Promise.all(['jet','small-ramp','medium-ramp','large-ramp'].map(async id=>{
      const value=JSON.parse(await fs.readFile(`public/reference-replicas/${id}.json`,'utf8'));
      const generated=Date.parse(value.report.generatedAt);
      return {id,validationCodeHash:value.report.validationCodeHash,generatedAt:value.report.generatedAt,
        generatedInThisStage:value.report.validationCodeHash===expected&&Number.isFinite(generated)&&generated>=Date.parse(startedAt)&&generated<=Date.now()};
    }));
  }
  const outputsCurrent=reportFreshness===null||reportFreshness.every(row=>row.generatedInThisStage);

  const row={name:spec.name,command:[spec.command,...spec.args],startedAt,finishedAt:new Date().toISOString(),durationSeconds:(performance.now()-start)/1000,exitCode:result.code,signal:result.signal,contextUnchanged,log:archiveLog,logSha256:sha(logBytes),outputs,reportFreshness,outputsCurrent};
  evidence.stages.push(row);await save();console.log(JSON.stringify({state:'finished',stage:spec.name,exitCode:row.exitCode,contextUnchanged,durationSeconds:row.durationSeconds}));
  if(result.code!==0||!contextUnchanged||!outputsCurrent){await fs.writeFile('/tmp/magnatiles-source-sets-source-retry-active.json',JSON.stringify({state:'failed',...row},null,2)+'\n');process.exitCode=1;return;}
 }
 evidence.completed=true;evidence.finishedAt=new Date().toISOString();await save();await fs.writeFile('/tmp/magnatiles-source-sets-source-retry-active.json',JSON.stringify({state:'completed',manifest:prefix+'.manifest.json',validationCodeHash:expected},null,2)+'\n');
})().catch(error=>{console.error(error);process.exitCode=1;});
