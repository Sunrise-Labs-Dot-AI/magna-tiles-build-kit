const fs = require('node:fs/promises'), { spawn } = require('node:child_process'), crypto = require('node:crypto'), zlib = require('node:zlib'), assert = require('node:assert/strict');
const { validationCodeHash, artifactHashes } = require(process.cwd() + '/lib/replication/provenance.ts');
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
(async () => {
 const prefix = 'runs/diagnostics/2026-09-28-gyroscopic-negative-seed';
 const inputs = ['scripts/reference/probe-gyroscopic-negative-input.config.ts','scripts/reference/probe-gyroscopic-negative-control.config.ts','scripts/reference/gyroscopic-tile-probe.config.ts','scripts/reference/probe-gyroscopic-semantics.config.ts','scripts/reference/gyroscopic-probe-context.ts','scripts/reference/gyroscopic-f64-profile.json','runs/2026-09-28-gyroscopic-negative-control-plan.md','tests/fixtures/unpatched-contact.ts','tests/fixtures/contact-frames.ts','tests/triangle-contact.test.ts','vitest.config.ts'];
 const native = '/tmp/magnatiles-gyroscopic-probe-f64-principal-frame/source/rapier-compat/builds/3d/pkg/rapier.cjs';
 const context = async () => ({ production: await validationCodeHash(), inputs: await artifactHashes(inputs), nativeSha256: hash(await fs.readFile(native)), runnerSha256: hash(await fs.readFile(__filename)) });
 const before = await context(); assert.equal(before.production, 'b354b6edcbcddb7248137e9888e97badfcb7eb2156f742760783587be5dbcf1a');
 const e = { scope: 'Capture original production engine seed rotations and geometry before the historical f32 defect reproduction; no experimental dynamics', before, completed: false, cases: [], archives: [] };
 const save = () => fs.writeFile(prefix + '.manifest.json', JSON.stringify(e,null,2)+'\n');
 await fs.writeFile(prefix + '.manifest.json',JSON.stringify(e,null,2)+'\n',{flag:'wx'});
 const archive = async (source,suffix) => { const raw=await fs.readFile(source),bytes=suffix.endsWith('.gz')?zlib.gzipSync(raw):raw,path=prefix+'.'+suffix; await fs.writeFile(path,bytes,{flag:'wx'});e.archives.push({source,path,rawSha256:hash(raw),sha256:hash(bytes)}); };
 for(const [i,path] of inputs.entries())await archive(path,'input-'+i+'.gz');await archive(__filename,'runner.cjs.gz');await save();
 for(const mode of ['production']) {
  const report='/tmp/magnatiles-gyro-negative-seed-'+mode+'.json',log='/tmp/magnatiles-gyro-negative-seed-'+mode+'.log';
  for(const path of [report,log]){try{await fs.access(path);throw Error('Existing attempt '+path);}catch(error){if(error.code!=='ENOENT')throw error;}}
  const args=['vitest','run','--config','scripts/reference/probe-gyroscopic-negative-input.config.ts', '--reporter=default','--reporter=json','--outputFile='+report];
  const fd=await fs.open(log,'wx'),start=performance.now(),child=spawn('npx',args,{env:{...process.env,MAGNATILES_NEGATIVE_INPUT:mode,MAGNATILES_GYRO_PRECISION:'f64',MAGNATILES_GYRO_FRAME_FIX:'1',MAGNATILES_GYRO_MODE:'on'},stdio:['ignore',fd.fd,fd.fd]});
  const result=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});await fd.close();
  const row={mode,command:['npx',...args],...result,durationSeconds:(performance.now()-start)/1000};
  await archive(log,mode+'.log.txt');
  try {await archive(report,mode+'.vitest.json.gz');const r=JSON.parse(await fs.readFile(report,'utf8'));Object.assign(row,{passed:r.numPassedTests,failed:r.numFailedTests,pending:r.numPendingTests});}catch(error){if(error.code!=='ENOENT')throw error;row.missing=report;}
  e.cases.push(row);await save();console.log(JSON.stringify(row));
 }
 e.after=await context();e.contextUnchanged=JSON.stringify(e.before)===JSON.stringify(e.after);e.completed=e.contextUnchanged&&e.cases.length===1&&e.cases.every(r=>r.code===0&&r.passed===1&&r.failed===0);await save();if(!e.completed)process.exitCode=1;
})().catch(error=>{console.error(error);process.exitCode=1;});
