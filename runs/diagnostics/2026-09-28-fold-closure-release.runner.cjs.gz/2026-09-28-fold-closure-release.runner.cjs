const fs=require('node:fs/promises'),{spawn}=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const {validationCodeHash,artifactHashes}=require(process.cwd()+'/lib/replication/provenance.ts');
const expected='b354b6edcbcddb7248137e9888e97badfcb7eb2156f742760783587be5dbcf1a';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const prerequisite=JSON.parse(await fs.readFile('runs/diagnostics/2026-09-28-source-sets-source-retry.manifest.json','utf8'));
 if(!prerequisite.completed)throw Error('Finish source reports before another native run');
 const prefix='runs/diagnostics/2026-09-28-fold-closure-release',report='/tmp/magnatiles-fold-closure-release.json',log='/tmp/magnatiles-fold-closure-release.log';
 for(const file of [prefix+'.manifest.json',report]){try{await fs.access(file);throw Error('Preserve existing attempt: '+file);}catch(e){if(e.code!=='ENOENT')throw e;}}
 const inputs=['scripts/reference/probe-fold-closure-release.ts','scripts/reference/probe-fold-closure-release.config.ts','runs/diagnostics/2026-09-27-native-fold-pivots.json.gz'];
 const context={validationCodeHash:await validationCodeHash(),inputHashes:await artifactHashes(inputs)};
 if(context.validationCodeHash!==expected)throw Error('Wrong runtime');
 const command=['npx','vitest','run','--config','scripts/reference/probe-fold-closure-release.config.ts'];
 const evidence={scope:'Captured fixed-pivot fold endpoint closure and release experiment. Completion records the protocol, not a release or source acceptance.',command,context,startedAt:new Date().toISOString(),runnerSha256:sha(await fs.readFile(__filename)),completed:false};
 const save=()=>fs.writeFile(prefix+'.manifest.json',JSON.stringify(evidence,null,2)+'\n');await save();
 const fd=await fs.open(log,'w'),start=performance.now(),child=spawn(command[0],command.slice(1),{cwd:process.cwd(),stdio:['ignore',fd.fd,fd.fd]});
 console.log(JSON.stringify({pid:child.pid,log,report}));
 const result=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});await fd.close();
 Object.assign(evidence,{finishedAt:new Date().toISOString(),durationSeconds:(performance.now()-start)/1000,exitCode:result.code,signal:result.signal,finalContext:{validationCodeHash:await validationCodeHash(),inputHashes:await artifactHashes(inputs)}});
 evidence.contextUnchanged=JSON.stringify(context)===JSON.stringify(evidence.finalContext);evidence.archives=[];
 for(const [source,name] of [[log,'log.txt'],[report,'json.gz'],[inputs[0],'script.ts.gz'],[inputs[1],'config.ts.gz']]){
  let raw;try{raw=await fs.readFile(source);}catch(e){if(e.code==='ENOENT'){evidence.archives.push({source,missing:true});continue;}throw e;}
  const bytes=name.endsWith('.gz')?zlib.gzipSync(raw,{mtime:0}):raw,path=prefix+'.'+name;
  await fs.writeFile(path,bytes);evidence.archives.push({source,path,rawSha256:sha(raw),sha256:sha(bytes)});
 }
 evidence.completed=result.code===0&&evidence.contextUnchanged;await save();console.log(JSON.stringify(evidence));
 if(!evidence.completed)process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
