const fs=require('node:fs/promises'),{spawn}=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const {validationCodeHash,artifactHashes}=require(process.cwd()+'/lib/replication/provenance.ts');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const prefix='runs/diagnostics/2026-09-28-gyroscopic-principal-frame';
 const inputs=['scripts/reference/probe-spring-semantics.ts','scripts/reference/probe-free-spin.ts','scripts/reference/gyroscopic-probe-context.ts','scripts/reference/probe-gyroscopic-semantics.config.ts','scripts/reference/probe-gyroscopic-free-spin.ts','scripts/reference/build-gyroscopic-probe.py','runs/2026-09-28-gyroscopic-probe-plan.md','runs/2026-09-28-compliant-seam-plan.md','scripts/reference/gyroscopic-f64-profile.json','scripts/reference/gyroscopic-f64-wrapper.patch','scripts/reference/gyroscopic-f64.Cargo.lock','runs/2026-09-28-gyroscopic-precision-plan.md','runs/2026-09-28-gyroscopic-refinement-plan.md','runs/2026-09-28-gyroscopic-principal-frame-plan.md'];
 const context={validationCodeHash:await validationCodeHash(),inputHashes:await artifactHashes(inputs),buildProof:JSON.parse(await fs.readFile('/tmp/magnatiles-gyroscopic-probe-f64-principal-frame/build-proof.json','utf8'))};
 if(context.validationCodeHash!=='b354b6edcbcddb7248137e9888e97badfcb7eb2156f742760783587be5dbcf1a')throw Error('Production context changed');
 const evidence={scope:'Corrected principal-frame gyro with full precision at free-pair timestep0.000025; does not pass the original1e-4 configuration. completed requires original physics checks, executionCompleted only records all rows ran.',context,startedAt:new Date().toISOString(),runnerSha256:hash(await fs.readFile(__filename)),completed:false,executionCompleted:false,cases:[],archives:[]};
 await fs.writeFile(prefix+'.manifest.json',JSON.stringify(evidence,null,2)+'\n',{flag:'wx'});
 const archive=async(source,suffix)=>{const raw=await fs.readFile(source),bytes=suffix.endsWith('.gz')?zlib.gzipSync(raw):raw,path=prefix+'.'+suffix;await fs.writeFile(path,bytes,{flag:'wx'});evidence.archives.push({source,path,rawSha256:hash(raw),sha256:hash(bytes)});};
 for(const mode of ['on']){
   const report='/tmp/magnatiles-gyro-principal-frame-'+mode+'-spring.json',spin='/tmp/magnatiles-gyro-principal-frame-'+mode+'-spin.json',log='/tmp/magnatiles-gyro-principal-frame-'+mode+'.log';
   for(const path of [report,spin,log]){try{await fs.access(path);throw Error('Existing attempt '+path);}catch(e){if(e.code!=='ENOENT')throw e;}}
   const command=['npx','vitest','run','--config','scripts/reference/probe-gyroscopic-semantics.config.ts'];
   const fd=await fs.open(log,'wx'),start=performance.now(),child=spawn(command[0],command.slice(1),{cwd:process.cwd(),env:{...process.env,MAGNATILES_GYRO_MODE:mode,MAGNATILES_SPRING_FREE_DT:'0.000025',MAGNATILES_SPRING_REPORT:report,MAGNATILES_SPIN_REPORT:spin},stdio:['ignore',fd.fd,fd.fd]});
   console.log(JSON.stringify({mode,pid:child.pid,log}));
   const result=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});await fd.close();
   const row={mode,command,...result,durationSeconds:(performance.now()-start)/1000};
   for(const [source,suffix] of [[log,mode+'.log.txt'],[report,mode+'.spring.json.gz'],[spin,mode+'.spin.json.gz']]){
    try{await archive(source,suffix);}catch(e){if(e.code!=='ENOENT')throw e;row.missing=(row.missing||[]).concat(source);}
   }
   if(!row.missing){const r=JSON.parse(await fs.readFile(report,'utf8')),s=JSON.parse(await fs.readFile(spin,'utf8'));Object.assign(row,{forceRows:r.forces.length,freeRows:r.free.length,checks:r.checks.length,failedChecks:r.checks.filter(c=>!c.pass).length,error:r.error,springPassed:r.completed,spinRows:s.rows.length,spinPassed:s.rows.every(r=>r.conservesSpin)});}
   evidence.cases.push(row);await fs.writeFile(prefix+'.manifest.json',JSON.stringify(evidence,null,2)+'\n');
 }
 evidence.finalContext={validationCodeHash:await validationCodeHash(),inputHashes:await artifactHashes(inputs),buildProof:JSON.parse(await fs.readFile('/tmp/magnatiles-gyroscopic-probe-f64-principal-frame/build-proof.json','utf8'))};
 evidence.contextUnchanged=JSON.stringify(context)===JSON.stringify(evidence.finalContext);
 evidence.executionCompleted=evidence.contextUnchanged&&evidence.cases.every(r=>!r.missing&&r.error===null&&r.forceRows===11&&r.freeRows===13&&r.checks===247&&r.spinRows===6);
 evidence.completed=evidence.executionCompleted&&evidence.cases.every(r=>r.code===0&&r.springPassed&&r.spinPassed);
 evidence.finishedAt=new Date().toISOString();
 for(const [i,path] of inputs.entries())await archive(path,'input-'+i+'.gz');
 await archive('/tmp/magnatiles-gyroscopic-probe-f64-principal-frame/build-proof.json','build-proof.json');await archive('/tmp/magnatiles-gyroscopic-probe-f64-principal-frame/gyroscopic-binding.patch','binding.patch');await archive(__filename,'runner.cjs.gz');await archive('/tmp/magnatiles-gyroscopic-probe-f64-principal-frame/principal-frame.patch','native.patch');await archive('/tmp/magnatiles-gyroscopic-probe-f64-principal-frame/source/builds/rapier3d/Cargo.lock','Cargo.lock');await archive('/tmp/magnatiles-gyroscopic-principal-frame-build.log','build.log.txt');
 await fs.writeFile(prefix+'.manifest.json',JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify({executionCompleted:evidence.executionCompleted,completed:evidence.completed,cases:evidence.cases}));
 if(!evidence.executionCompleted)process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1});
